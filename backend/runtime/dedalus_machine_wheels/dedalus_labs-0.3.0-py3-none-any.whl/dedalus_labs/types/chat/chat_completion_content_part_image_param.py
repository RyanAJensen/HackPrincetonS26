# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["ChatCompletionContentPartImageParam", "ImageURL"]


class ImageURL(TypedDict, total=False):
    """Schema for ImageUrl.

    Fields:
    - url (required): AnyUrl
    - detail (optional): Literal["auto", "low", "high"]
    """

    url: Required[str]
    """Either a URL of the image or the base64 encoded image data."""

    detail: Literal["auto", "low", "high"]
    """Specifies the detail level of the image.

    Learn more in the
    [Vision guide](/docs/guides/vision#low-or-high-fidelity-image-understanding).
    """


class ChatCompletionContentPartImageParam(TypedDict, total=False):
    """Learn about [image inputs](/docs/guides/vision).

    Fields:
    - type (required): Literal["image_url"]
    - image_url (required): ImageUrl
    """

    image_url: Required[ImageURL]
    """Schema for ImageUrl.

    Fields:

    - url (required): AnyUrl
    - detail (optional): Literal["auto", "low", "high"]
    """

    type: Required[Literal["image_url"]]
    """The type of the content part."""
